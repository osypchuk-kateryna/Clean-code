package models.planes.enams;

public enum MilitaryType {
    BOMBER,
    FIGHTER,
    TRANSPORTER
}
