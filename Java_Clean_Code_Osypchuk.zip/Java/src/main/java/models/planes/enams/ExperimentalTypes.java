package models.planes.enams;

public enum ExperimentalTypes {
    HIGH_ALTITUDE,
    HIGH_SPEED
}
