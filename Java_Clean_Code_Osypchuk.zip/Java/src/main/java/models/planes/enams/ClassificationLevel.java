package models.planes.enams;

public enum ClassificationLevel {
    SECRET,
    TOP_SECRET,
    UNCLASSIFIED
}
