package models.airport;

import models.planes.enams.MilitaryType;
import models.planes.ExperimentalPlane;
import models.planes.MilitaryPlane;
import models.planes.PassengerPlane;
import models.planes.Plane;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Airport {
    private final List<? extends Plane> list;

    public Airport(List<? extends Plane> planes) {
        this.list = planes;
    }

    public List<PassengerPlane> getPassengerPlane() {
        List<PassengerPlane> passengerPlanes = new ArrayList<>();
        for (Plane plane : this.list) {
            if (plane instanceof PassengerPlane) {
                passengerPlanes.add((PassengerPlane) plane);
            }
        }
        return passengerPlanes;
    }

    public List<MilitaryPlane> getMilitaryPlanes() {
        List<MilitaryPlane> militaryPlanes = new ArrayList<>();
        for (Plane plane : list) {
            if (plane instanceof MilitaryPlane) militaryPlanes.add((MilitaryPlane) plane);
        }
        return militaryPlanes;
    }

    public PassengerPlane getPassengerPlaneWithMaxPassengersCapacity() {
        List<PassengerPlane> passengerPlanes = getPassengerPlane();
        PassengerPlane planeWithMaxCapacity = passengerPlanes.get(0);
        for (PassengerPlane passengerPlane : passengerPlanes) {
            if (passengerPlane.getPassengersCapacity() > planeWithMaxCapacity.getPassengersCapacity()) {
                planeWithMaxCapacity = passengerPlane;
            }
        }
        return planeWithMaxCapacity;
    }

    public List<MilitaryPlane> getTransportMilitaryPlanes() {
        List<MilitaryPlane> transportMilitaryPlanes = new ArrayList<>();
        List<MilitaryPlane> militaryPlanes = getMilitaryPlanes();
        for (MilitaryPlane plane : militaryPlanes) {
            if (plane.getMilitaryType() == MilitaryType.TRANSPORTER) {
                transportMilitaryPlanes.add(plane);
            }
        }
        return transportMilitaryPlanes;
    }

    public List<MilitaryPlane> getBomberMilitaryPlanes() {
        List<MilitaryPlane> bomberMilitaryPlanes = new ArrayList<>();
        List<MilitaryPlane> militaryPlanes = getMilitaryPlanes();
        for (MilitaryPlane plane : militaryPlanes) {
            if (plane.getMilitaryType() == MilitaryType.BOMBER) {
                bomberMilitaryPlanes.add(plane);
            }
        }
        return bomberMilitaryPlanes;
    }

    public List<ExperimentalPlane> getExperimentalPlanes() {
        List<ExperimentalPlane> experimentalPlanes = new ArrayList<>();
        for (Plane plane : list) {
            if (plane instanceof ExperimentalPlane) {
                experimentalPlanes.add((ExperimentalPlane) plane);
            }
        }
        return experimentalPlanes;
    }

    public Airport sortByMaxDistance() {
        list.sort((Comparator<Plane>) (firstPlane, secondPlane) -> firstPlane.getMaxFlightDistance() - secondPlane.getMaxFlightDistance());
        return this;
    }

    public Airport sortByMaxSpeed() {
        list.sort((Comparator<Plane>) (firstPlane, secondPlane) -> firstPlane.getMaxSpeed() - secondPlane.getMaxSpeed());
        return this;
    }

    public void sortByMaxLoadCapacity() {
        list.sort((Comparator<Plane>) (firstPlane, secondPlane) -> firstPlane.getMaxLoadCapacity() - secondPlane.getMaxLoadCapacity());
    }

    public List<? extends Plane> getList() {
        return list;
    }

    @Override
    public String toString() {
        return "models.airport.Airport{" +
                "Planes=" + list.toString() +
                '}';
    }
}

